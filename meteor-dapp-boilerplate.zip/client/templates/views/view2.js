/**
Template Controllers

@module Templates
*/

/**
The view2 template

@class [template] views_view2
@constructor
*/

Template['views_view2'].onCreated(function() {
	  Meta.setSuffix(TAPi18n.__("dapp.view2.title"));
});
